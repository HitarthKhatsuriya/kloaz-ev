from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3, os, hashlib, secrets
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__, static_folder="", template_folder="")
CORS(app)

DB_NAME = "ev_stations.db"
TOKEN_EXPIRY_HOURS = 24


def db():
    con = sqlite3.connect(DB_NAME)
    con.row_factory = sqlite3.Row
    return con

def hash_pass(password):
    return hashlib.sha256(password.encode()).hexdigest()

def init_db():
    con = db()
    c = con.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS users(
        owner_id TEXT PRIMARY KEY,
        name TEXT,
        email TEXT UNIQUE,
        password_hash TEXT,
        role TEXT CHECK(role IN ('owner','admin'))
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS stations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        location TEXT,
        type TEXT,
        owner_id TEXT,
        verified BOOLEAN DEFAULT 1
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS tokens(
        token TEXT PRIMARY KEY,
        owner_id TEXT,
        expires_at TIMESTAMP
    )""")

    c.execute("SELECT COUNT(*) FROM users")
    if c.fetchone()[0] == 0:
        users = [
            ("owner_123","GreenCharge Pvt Ltd","owner@test.com",hash_pass("123"),"owner"),
            ("owner_456","SkyCharge Energy","owner2@test.com",hash_pass("456"),"owner"),
            ("admin_1","Super Admin","admin@test.com",hash_pass("admin"),"admin")
        ]
        c.executemany("INSERT INTO users VALUES (?,?,?,?,?)", users)

    c.execute("SELECT COUNT(*) FROM stations")
    if c.fetchone()[0] == 0:
        demo = [
            ("GreenCharge Superfast Hub","Ahmedabad • SG Highway","DC Fast", "owner_123", True),
            ("CityCharge AC Point","Mumbai • Andheri West","AC", "owner_456", True),
            ("Highway EV Plaza","Surat • NH48 Exit 12","DC", "owner_123", True),
            ("MetroMall Charging Bay","Delhi • Saket","AC", "owner_456", True),
            ("Airport EV Lounge","Bengaluru • T2 Parking","DC Fast", "owner_123", True),
        ]
        c.executemany("INSERT INTO stations(name,location,type,owner_id,verified) VALUES (?,?,?,?,?)", demo)

    con.commit()
    con.close()



def make_token():
    return secrets.token_hex(32)

def verify_token(token):
    con = db()
    c = con.cursor()
    c.execute("SELECT owner_id, expires_at FROM tokens WHERE token=?", (token,))
    row = c.fetchone()
    if not row: return None

    if datetime.fromisoformat(row["expires_at"]) < datetime.now():
        return None

    return row["owner_id"]

def login(role):
    data = request.json
    email, password = data["email"], hash_pass(data["password"])

    con = db()
    c = con.cursor()
    c.execute("SELECT owner_id FROM users WHERE email=? AND password_hash=? AND role=?", (email, password, role))
    user = c.fetchone()

    if not user:
        return jsonify({"message": "Invalid credentials"}), 401

    token = make_token()
    expiry = (datetime.now() + timedelta(hours=TOKEN_EXPIRY_HOURS)).isoformat()

    c.execute("DELETE FROM tokens WHERE owner_id=?", (user["owner_id"],))
    c.execute("INSERT INTO tokens VALUES (?,?,?)", (token, user["owner_id"], expiry))
    con.commit()

    return jsonify({"token": token, "owner_id": user["owner_id"], "role": role})


def auth_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization","")
        if not auth.startswith("Bearer "):
            return jsonify({"message":"Unauthorized"}), 401
        token = auth.split()[1]
        user = verify_token(token)
        if not user:
            return jsonify({"message":"Invalid or expired token"}), 401
        request.owner_id = user
        return f(*args, **kwargs)
    return wrapper



# --------- FIXED TO SERVE index1.html ---------
@app.route("/")
def serve_home():
    return send_from_directory(".", "stations.html")



@app.route("/api/stations", methods=["GET"])
def get_stations():
    con = db()
    c = con.cursor()
    c.execute("SELECT * FROM stations WHERE verified=1")
    result = [dict(row) for row in c.fetchall()]
    return jsonify({"stations": result})


@app.route("/api/login/owner", methods=["POST"])
def owner_login(): return login("owner")

@app.route("/api/login/admin", methods=["POST"])
def admin_login(): return login("admin")


@app.route("/api/stations/add", methods=["POST"])
@auth_required
def add_station():
    data = request.json
    con = db()
    c = con.cursor()

    c.execute("""
    INSERT INTO stations(name,location,type,owner_id,verified)
    VALUES(?,?,?,?,?)
    """, (data["name"], data["location"], data["type"], request.owner_id, data["verified"]))

    con.commit()
    return jsonify({"message":"Station added"})


@app.route("/api/stations/update", methods=["POST"])
@auth_required
def update_station():
    data = request.json

    con = db()
    c = con.cursor()
    c.execute("UPDATE stations SET name=?,location=?,type=?,verified=? WHERE id=?", (data["name"], data["location"], data["type"], data["verified"], data["id"]))
    con.commit()
    return jsonify({"message":"Station updated"})


@app.route("/api/stations/delete", methods=["POST"])
@auth_required
def delete_station():
    data = request.json
    con = db()
    c = con.cursor()
    c.execute("DELETE FROM stations WHERE id=?", (data["id"],))
    con.commit()
    return jsonify({"message":"Station deleted"})


if __name__ == "__main__":
    init_db()
    print("\n➡ Backend running at:  http://localhost:5000\n")
    app.run(debug=True)
